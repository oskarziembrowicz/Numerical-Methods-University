vector<vector<unsigned int>> points(n/2);

    // for (int i=0; i<(int)(n/2); i++) {
    //     points[i] = vector<unsigned int>(2);
    // }