#include <stdio.h>

void zad1() {
    const int N = 10;
    int arr[N]
    int x =2;
}

int main() {

    return 0;
}